package za.pnp.Backend.dao;

import java.util.List;

import za.pnp.Backend.dto.Address;
import za.pnp.Backend.dto.Cart;
import za.pnp.Backend.dto.User;

public interface UserDAO {

	// user related operation
	User getByEmail(String email);
	User get(int id);
	
	boolean addUser(User user);
	
	// adding and updating a new address
	Address getAddress(int addressId);
	boolean addAddress(Address address);
	boolean updateAddress(Address address);
	Address getBillingAddress(int userId);
	List<Address> listShippingAddresses(int userId);
	
/*
	Address getBillingAddress(User user);
	List<Address> listShippingAddress(User user);
 */
	
	
	// update a cart
	boolean updateCart(Cart cart);
	
	
}
