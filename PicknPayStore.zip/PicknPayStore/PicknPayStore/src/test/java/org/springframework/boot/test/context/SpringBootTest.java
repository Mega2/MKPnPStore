package org.springframework.boot.test.context;

public class SpringBootTest {

}
