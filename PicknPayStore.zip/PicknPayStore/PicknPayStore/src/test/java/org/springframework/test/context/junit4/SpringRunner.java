package org.springframework.test.context.junit4;

public class SpringRunner {

}
