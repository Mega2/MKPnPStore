package za.pnp.PicknPayStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


public class PicknPayStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicknPayStoreApplication.class, args);
	}
}
