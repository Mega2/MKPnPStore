package org.springframework.boot.autoconfigure;

public class SpringBootApplication {

}
