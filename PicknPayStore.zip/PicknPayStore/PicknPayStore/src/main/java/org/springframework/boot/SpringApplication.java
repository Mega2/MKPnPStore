package org.springframework.boot;

import za.pnp.PicknPayStore.PicknPayStoreApplication;

public class SpringApplication {

	public static void run1(Class<PicknPayStoreApplication> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

	public static void run(Class<PicknPayStoreApplication> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

}
